集計用の軽量版です。全着手・全反復の圧縮CSVはdetailed-data.zipに含まれます。
